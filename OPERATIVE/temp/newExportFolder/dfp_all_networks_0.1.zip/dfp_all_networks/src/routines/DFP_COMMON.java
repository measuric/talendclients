package routines;


import com.google.api.ads.common.lib.auth.OfflineCredentials;
import com.google.api.ads.common.lib.auth.OfflineCredentials.Api;
import com.google.api.ads.dfp.axis.factory.DfpServices;
import com.google.api.ads.dfp.axis.v201306.Network;
import com.google.api.ads.dfp.axis.v201306.NetworkServiceInterface;
import com.google.api.ads.dfp.lib.client.DfpSession;
import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.gson.GsonFactory;
import java.util.*;
import java.io.*;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
public class DFP_COMMON {
	

	public static void runExample(DfpServices dfpServices, DfpSession session) throws Exception {
		  // Get the NetworkService.
		  NetworkServiceInterface networkService =
		      dfpServices.get(session, NetworkServiceInterface.class);

		  // Get all networks that you have access to with the current login credentials.
		  Network[] networks = networkService.getAllNetworks();

		  int i = 0;
		  for (Network network : networks) {
		    System.out.printf("%s) Network with network code \"%s\" and display name \"%s\" was found.\n",
		        0, network.getNetworkCode(), network.getDisplayName());
		    i++;
		  }

		  System.out.printf("Number of networks found: %s\n", networks.length);
		}


public static Credential getOAuth2Credential() throws Exception {
	String[] scope = {"https://www.google.com/apis/ads/publisher"};
	List list = Arrays.asList(scope); 
	  // Service account credential.
	  GoogleCredential credential = new GoogleCredential.Builder().setTransport(
	      new NetHttpTransport())
	      .setJsonFactory(new GsonFactory())
	      .setServiceAccountId(
	          "521392361473-5ba7pbjspg671hc7rvaqrm4ta1vj1a11@developer.gserviceaccount.com")
	      .setServiceAccountScopes(list)
	      .setServiceAccountPrivateKeyFromP12File(new File("C:/Vikram Takkar/freelance_jobs/Elance/Google DFP/key/793c311828b4f6ef733d483b19ba5a8a6f40ecbf-privatekey.p12"))
	      // Set the user you are impersonating (this can be yourself).
	      .setServiceAccountUser("dinomathieus@measuric.com")
	      .build();

	  credential.refreshToken();
	  return credential;
	}

/**
 * Writes the contents of the URL to the file path.
 *
 * @param url the URL locating the report XML
 * @param filePath the file path to write to
 * @throws IOException if an I/O error occurs
 */
public static void downloadFile(String url, String filePath) throws IOException {
  BufferedInputStream inputStream = new BufferedInputStream(new URL(url).openStream());
  BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(filePath));

  try {
    int i = 0;
    while ((i = inputStream.read()) != -1) {
    	//System.out.println(i+"");
      bos.write(i);
    }
  } finally {
    if (inputStream != null) {
      inputStream.close();
    }

    if (bos != null) {
      bos.close();
    }
  }
}

	public static void print(String str)
	{
	System.out.println(str);
	}
}


