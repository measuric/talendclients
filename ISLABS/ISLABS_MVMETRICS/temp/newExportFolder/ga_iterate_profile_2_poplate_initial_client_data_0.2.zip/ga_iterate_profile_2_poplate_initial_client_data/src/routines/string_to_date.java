package routines;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class string_to_date {

    public static Date convert2Date(String string_date,String date_format) throws Exception{

    	SimpleDateFormat sdf = new SimpleDateFormat(date_format);
    	Date transformed_date = sdf.parse(string_date);
    	return transformed_date;
    }
}
