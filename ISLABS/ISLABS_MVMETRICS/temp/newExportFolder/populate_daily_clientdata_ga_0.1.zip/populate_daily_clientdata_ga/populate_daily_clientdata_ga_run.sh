#!/bin/sh
cd `dirname $0`
 ROOT_PATH=`pwd`
 java -Xms256M -Xmx1024M -cp $ROOT_PATH/../lib/cimt.talendcomp.gaanalytics-1.5.0-jar-with-dependencies.jar:$ROOT_PATH/../lib/dom4j-1.6.1.jar:$ROOT_PATH/../lib/mysql-connector-java-5.1.22-bin.jar:$ROOT_PATH/../lib/talendcsv.jar:$ROOT_PATH:$ROOT_PATH/../lib/systemRoutines.jar:$ROOT_PATH/../lib/userRoutines.jar::.:$ROOT_PATH/populate_daily_clientdata_ga_0_1.jar:$ROOT_PATH/dymanically_fetching_ga_data_0_1.jar: islabs_mvmetrics.populate_daily_clientdata_ga_0_1.populate_daily_clientdata_ga --context=Default "$@" 