package routines;

public class seomoz_common {

}
